from flask import Flask, render_template, request, redirect, url_for, flash

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Für Flash-Nachrichten

# Speicher für die Daten (wird in späteren Versionen durch SQLite ersetzt)
parts_data = []

@app.route('/')
def index():
    return render_template('overview.html')

@app.route('/input')
def input_page():
    return render_template('input.html')

@app.route('/submit', methods=['POST'])
def submit():
    # Daten aus dem Formular abrufen
    lib_nummer = request.form.get('lib_nummer')
    bezeichnung = request.form.get('bezeichnung')
    groesse = request.form.get('groesse')
    sub = request.form.get('sub')
    regal = request.form.get('regal')
    position = request.form.get('position')
    
    # Speichern der Daten (momentan nur in Speicher, nicht persistent)
    parts_data.append({
        'lib_nummer': lib_nummer,
        'bezeichnung': bezeichnung,
        'groesse': groesse,
        'sub': sub,
        'regal': regal,
        'position': position
    })
    
    flash('Eingabe wurde für den UI-Test übernommen.', 'success')
    return redirect(url_for('index'))

@app.route('/import')
def import_page():
    flash('Importieren wird in einer späteren Entwicklungsphase implementiert.', 'info')
    return redirect(url_for('input_page'))

@app.route('/export')
def export_page():
    flash('Exportieren wird in einer späteren Entwicklungsphase implementiert.', 'info')
    return redirect(url_for('input_page'))

@app.route('/print')
def print_page():
    flash('Drucken wird in einer späteren Entwicklungsphase implementiert.', 'info')
    return redirect(url_for('input_page'))

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5000)