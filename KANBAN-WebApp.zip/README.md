# KANBAN

Web-App-Version der Maschinenteile-Datenbank für UI-Testzwecke.

## Start in VS Code

```powershell
python -m pip install -r requirements.txt
python app.py
```

Die aktuelle Version enthält eine Webanwendung mit Übersichts- und Eingabeseite. Datenbank, Import, Export, PDF, Drucken, Suche und Filter sind noch nicht implementiert.

## Technologie

- Python Flask
- HTML5
- CSS3
- JavaScript (minimal)

## Funktionen

- Übersichtsseite mit Button zur Eingabe
- Eingabeseite mit allen benötigten Feldern
- Regal-Dropdown mit Werten RL, RM, RR
- Numerische Validierung für Position
- Platzhalter für Import, Export und Drucken
- Responsive Design

## Projektstruktur

```
KANBAN/
│
├── app.py
├── requirements.txt
├── README.md
│
├── templates/
│   ├── overview.html
│   └── input.html
│
├── static/
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── app.js
│
└── models/
    └── part.py
```